package kr.or.ddit.basic;

import javafx.application.Application;
import javafx.stage.Stage;

public class JavaFxTest extends Application{

	
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
//		Application.launch(args);
	}
}
